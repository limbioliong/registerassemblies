﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace ManagedClassLib32
{
    [ComVisible(true)]
    [Guid("63B34FB2-FD1F-47A2-85F9-D8915175D30C")]
    [ClassInterface(ClassInterfaceType.AutoDual)]
    [ProgId("ManagedClassLib32.ManagedClass")]
    public class ManagedClass
    {
        public ManagedClass()
        {
        }

        public void TestMethod01()
        {
            Console.WriteLine("ManagedClassLib32::ManagedClass TestMethod01()");
        }
    }
}
