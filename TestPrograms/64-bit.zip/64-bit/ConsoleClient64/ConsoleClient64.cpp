// ConsoleClient64.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>
#import "..\ManagedClassLib64\bin\Debug\ManagedClassLib64.tlb" raw_interfaces_only no_implementation
using namespace ManagedClassLib64;


void DoTest()
{
	_ManagedClassPtr sp_ManagedClass = NULL;

	sp_ManagedClass.CreateInstance(__uuidof(ManagedClass));

	sp_ManagedClass->TestMethod01();
}


int main()
{
	::CoInitialize(NULL);
	DoTest();
	::CoUninitialize();
	return 0;
}

