﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace ManagedClassLib64
{
    [ComVisible(true)]
    [Guid("6B83ACAF-1A19-4978-80BC-0B2DD01403CC")]
    [ClassInterface(ClassInterfaceType.AutoDual)]
    [ProgId("ManagedClassLib64.ManagedClass")]
    public class ManagedClass
    {
        public ManagedClass()
        {
        }

        public void TestMethod01()
        {
            Console.WriteLine("ManagedClassLib64::ManagedClass TestMethod01()");
        }
    }
}
